class Game < Sequel::Model
  self.dataset = :games
end
