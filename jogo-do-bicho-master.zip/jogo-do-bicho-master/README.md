JOGO DO BICHO

web scraper para extrair os resultados do jogo do bicho encontrados no site [www.ojogodobicho.com/deu_no_post.htm](www.ojogodobicho.com/deu_no_post.htm)

REQUERIMENTOS

* node
* ruby
* bundler
* postgres



