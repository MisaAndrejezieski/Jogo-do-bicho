const app = document.getElementById('app');

app.innerText = 'Hello World';
